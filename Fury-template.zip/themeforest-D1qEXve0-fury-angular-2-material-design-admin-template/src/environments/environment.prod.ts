export const environment = {
  production: true,
  googleMapsApiKey: '',
  backend: '', // Put your backend here
};
