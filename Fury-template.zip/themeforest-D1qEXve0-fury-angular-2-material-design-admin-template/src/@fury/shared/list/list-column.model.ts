export class ListColumn {
  name?: string;
  property?: string;
  visible?: boolean;
  isModelProperty?: boolean;
  displayFn: any;
}
