export enum SidenavState {
  Fixed = 'fixed',
  Expanded = 'expanded',
  Collapsed = 'collapsed',
  CollapsedHover = 'collapsedHover',
  Mobile = 'mobile',
  MobileOpen = 'mobileOpen'
}
