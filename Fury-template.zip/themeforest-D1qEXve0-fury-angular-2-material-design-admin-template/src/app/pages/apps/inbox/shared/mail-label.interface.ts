export class MailLabel {
  name: string;
  color: string;
}
