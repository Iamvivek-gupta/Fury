export interface RecentSalesWidgetOptions {
  title: string;
  subTitle?: string;
}
