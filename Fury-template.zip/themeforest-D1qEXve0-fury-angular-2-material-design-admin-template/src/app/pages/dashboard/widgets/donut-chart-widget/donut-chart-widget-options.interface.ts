export class DonutChartWidgetOptions {
  title: string;
  subTitle?: string;

}
