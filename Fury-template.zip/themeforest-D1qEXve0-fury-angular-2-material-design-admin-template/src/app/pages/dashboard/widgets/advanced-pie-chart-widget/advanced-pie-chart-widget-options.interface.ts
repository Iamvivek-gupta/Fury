export class AdvancedPieChartWidgetOptions {
  title: string;
  subTitle?: string;
}
