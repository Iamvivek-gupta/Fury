import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fury-market-widget',
  templateUrl: './market-widget.component.html',
  styleUrls: ['./market-widget.component.scss']
})
export class MarketWidgetComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
