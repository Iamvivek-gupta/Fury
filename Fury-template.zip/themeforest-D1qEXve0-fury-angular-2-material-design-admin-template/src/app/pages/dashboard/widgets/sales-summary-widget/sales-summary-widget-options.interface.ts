export interface SalesSummaryWidgetOptions {
  title: string;
  subTitle?: string;
  gain?: number;
}
