import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fury-level5',
  templateUrl: './level5.component.html',
  styleUrls: ['./level5.component.scss']
})
export class Level5Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
