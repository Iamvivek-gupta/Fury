import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fury-page-layout-simple',
  templateUrl: './page-layout-simple.component.html',
  styleUrls: ['./page-layout-simple.component.scss']
})
export class PageLayoutSimpleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
