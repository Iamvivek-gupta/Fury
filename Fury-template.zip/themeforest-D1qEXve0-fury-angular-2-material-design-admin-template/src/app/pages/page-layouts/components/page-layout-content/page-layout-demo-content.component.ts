import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fury-page-layout-demo-content',
  templateUrl: './page-layout-demo-content.component.html',
  styleUrls: ['./page-layout-demo-content.component.scss']
})
export class PageLayoutDemoContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
