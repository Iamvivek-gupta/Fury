import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fury-page-layout-card',
  templateUrl: './page-layout-card.component.html',
  styleUrls: ['./page-layout-card.component.scss']
})
export class PageLayoutCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
